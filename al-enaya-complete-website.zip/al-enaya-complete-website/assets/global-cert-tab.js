(() => {
  if (document.querySelector('.global-certifications-tab')) return;

  const tab = document.createElement('a');
  tab.className = 'global-certifications-tab';
  tab.href = 'al-enaya-certifications.html';
  tab.setAttribute('aria-label', 'View our certifications');
  tab.innerHTML = '<span>OUR CERTIFICATIONS</span>';
  document.body.appendChild(tab);

  const style = document.createElement('style');
  style.textContent = `
    :root{--site-footer-navy:oklch(16% .045 250)}
    .footer,body>footer{background-color:var(--site-footer-navy)!important;background-image:none!important}
    .hero-slider:after{display:none!important}
    .global-certifications-tab{position:fixed;z-index:46;right:0;top:50%;display:flex;align-items:center;justify-content:center;min-height:154px;padding:18px 11px;writing-mode:vertical-rl;transform:translateY(-50%);color:#fff!important;background:#0155B6;border:1px solid rgb(255 255 255/.22);border-right:0;border-radius:10px 0 0 10px;box-shadow:0 14px 34px rgb(1 85 182/.24);font:700 9px/1.2 Manrope,Arial,sans-serif;letter-spacing:.12em;text-decoration:none;transition:transform .25s ease,background .25s ease,box-shadow .25s ease}
    .global-certifications-tab:hover{transform:translateY(-50%) translateX(-4px);background:#064b9b;box-shadow:0 18px 42px rgb(1 85 182/.34)}
    .global-certifications-tab:focus-visible{outline:3px solid rgb(83 170 133/.45);outline-offset:3px}
    @media(max-width:640px){.global-certifications-tab{min-height:132px;padding:14px 9px;font-size:8px;border-radius:8px 0 0 8px}}
  `;
  document.head.appendChild(style);
})();
