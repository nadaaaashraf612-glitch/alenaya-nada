# AL-ENAYA Website — Elementor Handoff

This package contains the completed static website source prepared for migration to WordPress and Elementor Widgets.

## Entry page

- `al-enaya-home.html`

## Pages

- `al-enaya-home.html` — Home
- `al-enaya-about.html` — About
- `al-enaya-services.html` — Services archive
- `al-enaya-service-details.html` — Dynamic single-service layout
- `al-enaya-projects.html` — Projects archive
- `al-enaya-project-category.html` — Dynamic project-category layout
- `al-enaya-project-details.html` — Dynamic single-project layout
- `al-enaya-clients.html` — Clients
- `al-enaya-certifications.html` — Certifications
- `al-enaya-contact.html` — Contact
- `faq.html` — FAQ
- `privacy.html` — Privacy Policy

## Shared components and assets

- `assets/internal-nav.js` — shared internal navigation component
- `assets/global-cert-tab.js` — sticky certifications tab and shared footer color rule
- `assets/internal-hero-overlay.css` — shared internal hero treatment
- `assets/contact-map-theme.css` — branded map treatment
- `assets/` — website imagery
- `image-1.png` — brand logo sprite used by navigation and footer

## Elementor migration notes

- Convert the shared navigation, footer, sticky certifications tab and CTA panels into Elementor global widgets/templates.
- Convert the services and projects data currently selected through URL parameters into WordPress custom post types and taxonomies.
- Preserve the service/project URL parameters during the static review; replace them with WordPress permalinks during migration.
- Google Maps, Google Fonts and GSAP are loaded externally and require internet access.
- Certificate PDFs are included in the package for upload to the WordPress Media Library.
